# QR Certificate Verification System

Open `index.html` in a browser.

Features:
- Certificate number input
- Learner/course/date fields
- Configurable verification domain
- Automatic verification URL
- QR code generation
- Copy verification link
- Download QR as PNG
- Verification-page preview

IMPORTANT:
This is the front-end generator/prototype. For real public certificate verification, the verification URL must point to a live website/backend that stores certificate records and validates the certificate number. Do not treat the preview as a secure verification database.

The QR library is loaded from a CDN, so internet access is required when opening the page.
